import Frame.WelcomeFrame;

public class Start {
    public static void main(String[] args) {
        WelcomeFrame welcomeFrame = new WelcomeFrame();
        welcomeFrame.run();
    }
}
