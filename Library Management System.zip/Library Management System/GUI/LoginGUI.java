package GUI;

import Entities.User;
import FileManagement.UserManager;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import javax.imageio.ImageIO;

public class LoginGUI extends JFrame implements ActionListener {
    private JTextField txtUsername;
    private JPasswordField txtPassword;
    private JButton btnLogin, btnRegister;
    private Image backgroundImage;

    public LoginGUI() {
        setTitle("Login");
        setSize(500, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        try {
            backgroundImage = ImageIO.read(new File("C:\\Users\\USER\\Music\\Library Management System\\images.jpeg")); // Change to your image path
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Set up the JPanel for components
        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                // Draw the background image
                g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
            }
        };

        panel.setLayout(null); // Use absolute layout
        add(panel);

        // Title label in bold
        JLabel titleLabel = new JLabel("<html><b>Library Management System</b></html>");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24)); // Adjust font and size as needed
        titleLabel.setBounds(10, 10, 400, 30); // Set position and size for the title
        panel.add(titleLabel);

        // Create and add components
        JLabel lblUsername = new JLabel("Username:");
        lblUsername.setBounds(10, 50, 80, 25);
        panel.add(lblUsername);

        txtUsername = new JTextField();
        txtUsername.setBounds(100, 50, 160, 25);
        panel.add(txtUsername);

        JLabel lblPassword = new JLabel("Password:");
        lblPassword.setBounds(10, 80, 80, 25);
        panel.add(lblPassword);

        txtPassword = new JPasswordField();
        txtPassword.setBounds(100, 80, 160, 25);
        panel.add(txtPassword);

        btnLogin = new JButton("Login");
        btnLogin.setBounds(10, 110, 80, 25);
        panel.add(btnLogin);
        btnLogin.addActionListener(this);

        btnRegister = new JButton("Register");
        btnRegister.setBounds(100, 110, 160, 25);
        panel.add(btnRegister);
        btnRegister.addActionListener(this);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnLogin) {
            login();
        } else if (e.getSource() == btnRegister) {
            register();
        }
    }

    private void login() {
        String username = txtUsername.getText();
        String password = new String(txtPassword.getPassword());

        UserManager um = new UserManager();
        if (um.loginUser(username, password)) {
            JOptionPane.showMessageDialog(this, "Login Successful!");
            new BookRegGUI(); // Open the book registration GUI
            dispose(); // Close the login window
        } else {
            JOptionPane.showMessageDialog(this, "Invalid credentials. Please try again.");
        }
    }

    private void register() {
        String username = txtUsername.getText();
        String password = new String(txtPassword.getPassword());

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "All fields must be filled!");
            return;
        }

        UserManager um = new UserManager();
        um.registerUser(new User(username, password));
        JOptionPane.showMessageDialog(this, "Registration Successful! You can now log in.");
    }
}
