package FileManagement;
import Entities.Book;
import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;

public class BookManager {
    public void writeBook(Book b, boolean append) {
        File f = new File("DataFiles/books.txt");
        try {
            FileWriter writer = new FileWriter(f, append);
            writer.write(b.getFileWriteFormat());
            writer.flush();
            writer.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public Book[] getAllBooks() {
        File file = new File("DataFiles/books.txt");

        if (!file.exists() || file.length() == 0) {
            return new Book[0];
        }

        Book[] books = null;
        try {
            Scanner sc2 = new Scanner(file);
            int count = 0;
            while (sc2.hasNextLine()) {
                sc2.nextLine();
                count++;
            }
            sc2.close();

            books = new Book[count];
            count = 0;

            Scanner sc = new Scanner(file);
            while (sc.hasNextLine()) {
                String line = sc.nextLine();
                String[] data = line.split(";");
                if (data.length == 5) {
                    Book b = new Book(Integer.parseInt(data[0]), data[1], data[2], Integer.parseInt(data[3]), Double.parseDouble(data[4]));
                    books[count] = b;
                    count++;
                }
            }
            sc.close();

        } catch (Exception ex) {
            System.out.println("Exception Occurred: " + ex.getMessage());
            ex.printStackTrace();
        }
        return books;
    }

    public Book searchBook(int sl) {
        Book[] books = getAllBooks();
        if (books != null) {
            for (int i = 0; i < books.length; i++) {
                if (books[i].getSl() == sl) {
                    return books[i];
                }
            }
        }
        return null;
    }

    public void deleteBook(int sl) {
        Book[] books = getAllBooks();
        if (books != null) {
            for (int i = 0; i < books.length; i++) {
                if (books[i].getSl() == sl) {
                    books[i] = null;
                }
            }
            try {
                FileWriter writer = new FileWriter("DataFiles/books.txt");
                for (int i = 0; i < books.length; i++) {
                    if (books[i] != null) {
                        writer.write(books[i].getFileWriteFormat());
                    }
                }
                writer.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    public void updateBook(Book b) {
        Book[] books = getAllBooks();
        if (books != null) {
            for (int i = 0; i < books.length; i++) {
                if (books[i].getSl() == b.getSl()) {
                    books[i] = b;
                }
            }
            try {
                FileWriter writer = new FileWriter("DataFiles/books.txt");
                for (int i = 0; i < books.length; i++) {
                    if (books[i] != null) {
                        writer.write(books[i].getFileWriteFormat());
                    }
                }
                writer.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
}
