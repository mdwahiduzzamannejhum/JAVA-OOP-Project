package FileManagement;
import Entities.User;
import java.io.*;

public class UserManager {
    private final String FILE_PATH = "DataFiles/users.txt";
    private static final int MAX_USERS = 100;
    private User[] users = new User[MAX_USERS];
    private int userCount = 0;

    public boolean loginUser(String username, String password) {
        loadUsersFromFile();
        for (int i = 0; i < userCount; i++) {
            if (users[i].getUsername().equals(username) && users[i].getPassword().equals(password)) {
                return true;
            }
        }
        return false;
    }

    public void registerUser(User user) {
        if (userCount < MAX_USERS) {
            users[userCount] = user;
            userCount++;
            writeUserToFile(user);
        } else {
            System.out.println("User limit  full hye gese,r neya jabe na ");
        }
    }

    private void writeUserToFile(User user) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH, true))) {
            writer.write(user.getUsername() + ";" + user.getPassword());
            writer.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void loadUsersFromFile() {
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            userCount = 0;
            while ((line = reader.readLine()) != null && userCount < MAX_USERS) {
                String[] parts = line.split(";");
                if (parts.length == 2) {
                    users[userCount] = new User(parts[0], parts[1]);
                    userCount++;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
