import FileManagement.StudentManager;
import Entities.Student;
import GUI.StudentRegGUI;

public class Start{

    public static void main(String args[]){

        StudentRegGUI g =new StudentRegGUI();
        /*StudentManager sm = new StudentManager();
        Student[] students = sm.getAllStudent();
        System.out.println(students.length);*/
    }
    
}