package GUI;
import javax.swing.*;
import java.awt.FlowLayout; //awt = abstract window toolkit
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import FileManagement.StudentManager;
import Entities.Student;
import javax.swing.table.DefaultTableModel;
public class StudentRegGUI extends JFrame implements ActionListener{
    JTextField txtSl,txtName,txtSId,txtDob,txtSearch;
    JButton register,update,delete,search;
    DefaultTableModel tmodel;
    public StudentRegGUI(){
        setSize(1300,400);
        setLayout(new FlowLayout());
        /*JLabel id = new JLabel("Id");
        add(id);*/

        add(new JLabel("Search SL"));
        txtSearch = new JTextField(6);
        add(txtSearch);
        search = new JButton("Search");
        add(search);
        search.addActionListener(this);

        add(new JLabel("SL"));
        txtSl = new JTextField(6);
        add(txtSl);

        add(new JLabel("Name"));
        txtName = new JTextField(20);
        add(txtName);

        add(new JLabel("SId"));
        txtSId = new JTextField(8);
        add(txtSId);

        
        add(new JLabel("Dob"));
        txtDob = new JTextField(8);
        add(txtDob);

        register = new JButton("Register");
        add(register);
        register.addActionListener(this);
        update = new JButton("Update");
        add(update);
        update.addActionListener(this);
        delete = new JButton("Delete");
        add(delete);
        delete.addActionListener(this);

        tmodel = new DefaultTableModel();
        tmodel.addColumn("SL");
        tmodel.addColumn("Name");
        tmodel.addColumn("SId");
        tmodel.addColumn("Dob");
        JTable tbl = new JTable(tmodel);
        JScrollPane tbscrl = new JScrollPane(tbl);
        add(tbscrl);
        loadData();
        


        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e){
        if(e.getSource() == register){
            registerClicked();
        }
        else if(e.getSource() == update){
            updateClicked();
        }
        else if(e.getSource() == delete){
            deleteClicked();
        }
        else if(e.getSource() == search){
            searchClicked();
        }
        
    }
    public void registerClicked(){
        String sl = txtSl.getText();
        String name = txtName.getText();
        String sid = txtSId.getText();
        String dob = txtDob.getText();
        StudentManager sm = new StudentManager();
        Student s = new Student(sl,name,sid,dob);
        sm.writeStudent(s,true);
        tmodel.addRow(s.getTableRow());
        JOptionPane.showMessageDialog(null,"Student Inserted");



    }
    public void updateClicked(){
        String sl = txtSl.getText();
        String name = txtName.getText();
        String sid = txtSId.getText();
        String dob = txtDob.getText();
        Student s = new Student(sl,name,sid,dob);

        StudentManager sm = new StudentManager();
        sm.updateStudent(s);
        refreshTable();
        

        JOptionPane.showMessageDialog(null,"Updated");
    }
    public void deleteClicked(){
        String sl = txtSearch.getText();
        StudentManager sm = new StudentManager();
        sm.deleteStudent(Integer.parseInt(sl));
        refreshTable();
        JOptionPane.showMessageDialog(null,"Deleted");
    }
    public void loadData(){
        StudentManager sm = new StudentManager();
        Student[] students = sm.getAllStudent(); 
        for(int i=0;i<students.length;i++){
            tmodel.addRow(students[i].getTableRow());
        }
    }
    public void searchClicked(){
        String sl = txtSearch.getText();
        StudentManager sm = new StudentManager();
        Student s = sm.searchStudent(Integer.parseInt(sl));
        if(s == null){
            JOptionPane.showMessageDialog(null,"Student not found");
        }
        else{
            txtSl.setText(s.getSl()+"");
            txtName.setText(s.getName());
            txtSId.setText(s.getSId());
            txtDob.setText(s.getDob());
        }
        
    }
     public void refreshTable(){
        tmodel.getDataVector().removeAllElements();
        StudentManager sm = new StudentManager();
        Student[] students = sm.getAllStudent(); 
        for(int i=0;i<students.length;i++){
            tmodel.addRow(students[i].getTableRow());
        }

    }
}

