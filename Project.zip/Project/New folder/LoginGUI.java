
import javax.swing.*;
import javax.swing.JFrame;
import java.awt.FlowLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.table.DefaultTableModel;
import java.awt.Image;

public class LoginGUI extends JFrame  {
    JLabel l;
    ImageIcon i;
    public LoginGUI(){
        setSize(400,500);
        setLocation(200,200);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
        i=new ImageIcon("C:\\Users\\USER\\Documents\\library-study-area.jpg");
        l=new JLabel(i);
        add(l);
    }


    }
