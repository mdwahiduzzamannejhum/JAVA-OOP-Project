
import javax.swing.*;
public class Start {
    public static void main(String[] args) {
        LoginGUI g=new LoginGUI();
    }
}
