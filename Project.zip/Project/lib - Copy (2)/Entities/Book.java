package Entities;

public class Book {
    private int sl;
    private String title;
    private String author;
    private int publicationYear;
    private double price;

    public Book(int sl, String title, String author, int publicationYear, double price) {
        this.sl = sl;
        this.title = title;
        this.author = author;
        this.publicationYear = publicationYear;
        this.price = price;
    }

    public int getSl() {
        return sl;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public int getPublicationYear() {
        return publicationYear;
    }

    public double getPrice() {
        return price;
    }

    public String getFileWriteFormat() {
        return sl + ";" + title + ";" + author + ";" + publicationYear + ";" + price + "\n";
    }

    public Object[] getTableRow() {
        return new Object[]{sl, title, author, publicationYear, price};
    }
}
