package GUI;

import Entities.User;
import FileManagement.UserManager;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoginGUI extends JFrame implements ActionListener {
    private JTextField txtUsername;
    private JPasswordField txtPassword;
    private JButton btnLogin, btnRegister;

    public LoginGUI() {
        setTitle("Login");
        setSize(300, 200);
        setLayout(null);
        setLocationRelativeTo(null);

        JLabel lblUsername = new JLabel("Username:");
        lblUsername.setBounds(10, 20, 80, 25);
        add(lblUsername);

        txtUsername = new JTextField();
        txtUsername.setBounds(100, 20, 160, 25);
        add(txtUsername);

        JLabel lblPassword = new JLabel("Password:");
        lblPassword.setBounds(10, 50, 80, 25);
        add(lblPassword);

        txtPassword = new JPasswordField();
        txtPassword.setBounds(100, 50, 160, 25);
        add(txtPassword);

        btnLogin = new JButton("Login");
        btnLogin.setBounds(10, 80, 80, 25);
        add(btnLogin);
        btnLogin.addActionListener(this);

        btnRegister = new JButton("Register");
        btnRegister.setBounds(100, 80, 160, 25);
        add(btnRegister);
        btnRegister.addActionListener(this);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnLogin) {
            login();
        } else if (e.getSource() == btnRegister) {
            register();
        }
    }

    private void login() {
        String username = txtUsername.getText();
        String password = new String(txtPassword.getPassword());

        UserManager um = new UserManager();
        if (um.loginUser(username, password)) {
            JOptionPane.showMessageDialog(this, "Login Successful!");
            new BookRegGUI(); // Open the book registration GUI
            dispose(); // Close the login window
        } else {
            JOptionPane.showMessageDialog(this, "Invalid credentials. Please try again.");
        }
    }

    private void register() {
        String username = txtUsername.getText();
        String password = new String(txtPassword.getPassword());

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "All fields must be filled!");
            return;
        }

        UserManager um = new UserManager();
        um.registerUser(new User(username, password));
        JOptionPane.showMessageDialog(this, "Registration Successful! You can now log in.");
    }
}
