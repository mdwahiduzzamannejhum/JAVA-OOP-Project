package GUI;

import Entities.Book;
import FileManagement.BookManager;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class BookRegGUI extends JFrame implements ActionListener {
    private JTextField txtSl, txtTitle, txtAuthor, txtPublicationYear, txtPrice, txtSearch;
    private JButton register, update, delete, search;
    private DefaultTableModel tmodel;

    public BookRegGUI() {
        setSize(800, 400);
        setLayout(new FlowLayout());
        setLocationRelativeTo(null);

        add(new JLabel("Search SL"));
        txtSearch = new JTextField(10);
        add(txtSearch);
        search = new JButton("Search");
        add(search);
        search.addActionListener(this);

        add(new JLabel("SL"));
        txtSl = new JTextField(10);
        add(txtSl);

        add(new JLabel("Title"));
        txtTitle = new JTextField(20);
        add(txtTitle);

        add(new JLabel("Author"));
        txtAuthor = new JTextField(20);
        add(txtAuthor);

        add(new JLabel("Publication Year"));
        txtPublicationYear = new JTextField(6);
        add(txtPublicationYear);

        add(new JLabel("Price"));
        txtPrice = new JTextField(8);
        add(txtPrice);

        register = new JButton("Register");
        add(register);
        register.addActionListener(this);

        update = new JButton("Update");
        add(update);
        update.addActionListener(this);

        delete = new JButton("Delete");
        add(delete);
        delete.addActionListener(this);

        tmodel = new DefaultTableModel();
        tmodel.addColumn("SL");
        tmodel.addColumn("Title");
        tmodel.addColumn("Author");
        tmodel.addColumn("Publication Year");
        tmodel.addColumn("Price");
        JTable tbl = new JTable(tmodel);
        JScrollPane tbscrl = new JScrollPane(tbl);
        add(tbscrl);
        loadData();

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == register) {
            registerClicked();
        } else if (e.getSource() == update) {
            updateClicked();
        } else if (e.getSource() == delete) {
            deleteClicked();
        } else if (e.getSource() == search) {
            searchClicked();
        }
    }

    public void registerClicked() {
        String sl = txtSl.getText();
        String title = txtTitle.getText();
        String author = txtAuthor.getText();
        String pubYear = txtPublicationYear.getText();
        String price = txtPrice.getText();

        if (sl.isEmpty() || title.isEmpty() || author.isEmpty() || pubYear.isEmpty() || price.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill all fields.");
            return;
        }

        Book book = new Book(Integer.parseInt(sl), title, author, Integer.parseInt(pubYear), Double.parseDouble(price));
        BookManager bm = new BookManager();
        bm.writeBook(book, true);
        loadData(); // Refresh the table
    }

    public void updateClicked() {
        String sl = txtSl.getText();
        String title = txtTitle.getText();
        String author = txtAuthor.getText();
        String pubYear = txtPublicationYear.getText();
        String price = txtPrice.getText();

        if (sl.isEmpty() || title.isEmpty() || author.isEmpty() || pubYear.isEmpty() || price.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill all fields.");
            return;
        }

        Book book = new Book(Integer.parseInt(sl), title, author, Integer.parseInt(pubYear), Double.parseDouble(price));
        BookManager bm = new BookManager();
        bm.updateBook(book);
        loadData(); // Refresh the table
    }

    public void deleteClicked() {
        String sl = txtSl.getText();
        if (sl.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter SL to delete.");
            return;
        }

        BookManager bm = new BookManager();
        bm.deleteBook(Integer.parseInt(sl));
        loadData(); // Refresh the table
    }

    public void searchClicked() {
        String sl = txtSearch.getText();
        if (sl.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter SL to search.");
            return;
        }

        BookManager bm = new BookManager();
        Book book = bm.searchBook(Integer.parseInt(sl));
        if (book != null) {
            txtSl.setText(String.valueOf(book.getSl()));
            txtTitle.setText(book.getTitle());
            txtAuthor.setText(book.getAuthor());
            txtPublicationYear.setText(String.valueOf(book.getPublicationYear()));
            txtPrice.setText(String.valueOf(book.getPrice()));
        } else {
            JOptionPane.showMessageDialog(this, "Book not found.");
        }
    }

    private void loadData() {
        tmodel.setRowCount(0); // Clear existing data
        BookManager bm = new BookManager();
        Book[] books = bm.getAllBooks();
        for (Book book : books) {
            tmodel.addRow(book.getTableRow());
        }
    }
}
