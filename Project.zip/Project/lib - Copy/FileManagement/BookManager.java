package FileManagement;

import Entities.Book;
import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;

public class BookManager {

    public void writeBook(Book b, boolean append) {
        File f = new File("DataFiles/books.txt");
        try {
            FileWriter writer = new FileWriter(f, append);
            writer.write(b.getFileWriteFormat());
            writer.flush();
            writer.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public Book[] getAllBooks() {
        File file = new File("DataFiles/books.txt");

        // Check if the file exists and has content
        if (!file.exists() || file.length() == 0) {
            return new Book[0];  // Return an empty array if no data
        }

        Book[] books = null;
        try {
            // Count the number of lines in the file
            Scanner sc2 = new Scanner(file);
            int count = 0;
            while (sc2.hasNextLine()) {
                sc2.nextLine();
                count++;
            }
            sc2.close();  // Don't forget to close the Scanner!

            books = new Book[count];  // Initialize the array with the count
            count = 0;

            // Read the file and populate the array
            Scanner sc = new Scanner(file);
            while (sc.hasNextLine()) {
                String line = sc.nextLine();
                String[] data = line.split(";");
                if (data.length == 5) {
                    Book b = new Book(data[0], data[1], data[2], data[3], data[4]);
                    books[count] = b;
                    count++;
                }
            }
            sc.close();  // Close the Scanner after use

        } catch (Exception ex) {
            System.out.println("Exception Occurred: " + ex.getMessage());
            ex.printStackTrace();
        }
        return books;
    }

    public Book searchBook(int sl) {
        Book[] books = getAllBooks();
        if (books != null) {
            for (Book book : books) {
                if (book.getSl() == sl) {
                    return book;
                }
            }
        }
        return null;
    }

    public void deleteBook(int sl) {
        Book[] books = getAllBooks();
        if (books != null) {
            for (int i = 0; i < books.length; i++) {
                if (books[i].getSl() == sl) {
                    books[i] = null;
                }
            }
            for (int i = 0; i < books.length; i++) {
                if (books[i] != null) {
                    if (i == 0) {
                        writeBook(books[i], false);
                    } else {
                        writeBook(books[i], true);
                    }
                }
            }
        }
    }

    public void updateBook(Book b) {
        Book[] books = getAllBooks();
        if (books != null) {
            for (int i = 0; i < books.length; i++) {
                if (books[i].getSl() == b.getSl()) {
                    books[i].setTitle(b.getTitle());
                    books[i].setAuthor(b.getAuthor());
                    books[i].setPublicationYear(b.getPublicationYear());
                    books[i].setPrice(b.getPrice());
                }
            }
            for (int i = 0; i < books.length; i++) {
                if (i == 0) {
                    writeBook(books[i], false);
                } else {
                    writeBook(books[i], true);
                }
            }
        }
    }
}
