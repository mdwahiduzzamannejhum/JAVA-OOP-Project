package GUI;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import FileManagement.BookManager;
import Entities.Book;
import javax.swing.table.DefaultTableModel;

public class BookRegGUI extends JFrame implements ActionListener {
    JTextField txtSl, txtTitle, txtAuthor, txtPublicationYear, txtPrice, txtSearch;
    JButton register, update, delete, search;
    DefaultTableModel tmodel;

    public BookRegGUI() {
        setSize(1200, 500);
        setLayout(new FlowLayout());
        setLocationRelativeTo(null);


        // Add the rest of the components
        add(new JLabel("Search SL"));
        txtSearch = new JTextField(10);
        add(txtSearch);
        search = new JButton("Search");
        add(search);
        search.addActionListener(this);

        add(new JLabel("SL"));
        txtSl = new JTextField(10);
        add(txtSl);

        add(new JLabel("Title"));
        txtTitle = new JTextField(20);
        add(txtTitle);

        add(new JLabel("Author"));
        txtAuthor = new JTextField(20);
        add(txtAuthor);

        add(new JLabel("Publication Year"));
        txtPublicationYear = new JTextField(6);
        add(txtPublicationYear);

        add(new JLabel("Price"));
        txtPrice = new JTextField(8);
        add(txtPrice);

        // Load and resize the image
        ImageIcon icon = new ImageIcon("C:\\Users\\USER\\Music\\lib\\library_studing_students-2023.jpg"); // Replace with your image path
        Image img = icon.getImage(); // Get the original image
        Image scaledImg = img.getScaledInstance(400, 350, Image.SCALE_SMOOTH); // Resize the image to 200x150 pixels
        ImageIcon scaledIcon = new ImageIcon(scaledImg); // Convert back to ImageIcon

        // Add the image to the JLabel
        JLabel imgLabel = new JLabel(scaledIcon);
        add(imgLabel);

        register = new JButton("Register");
        add(register);
        register.addActionListener(this);

        update = new JButton("Update");
        add(update);
        update.addActionListener(this);

        delete = new JButton("Delete");
        add(delete);
        delete.addActionListener(this);

        tmodel = new DefaultTableModel();
        tmodel.addColumn("SL");
        tmodel.addColumn("Title");
        tmodel.addColumn("Author");
        tmodel.addColumn("Publication Year");
        tmodel.addColumn("Price");
        JTable tbl = new JTable(tmodel);
        JScrollPane tbscrl = new JScrollPane(tbl);
        add(tbscrl);
        loadData();

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == register) {
            registerClicked();
        } else if (e.getSource() == update) {
            updateClicked();
        } else if (e.getSource() == delete) {
            deleteClicked();
        } else if (e.getSource() == search) {
            searchClicked();
        }
    }

    public void registerClicked() {
        String sl = txtSl.getText();
        String title = txtTitle.getText();
        String author = txtAuthor.getText();
        String publicationYear = txtPublicationYear.getText();
        String price = txtPrice.getText();

        BookManager bm = new BookManager();
        Book b = new Book(sl, title, author, publicationYear, price);
        bm.writeBook(b, true);
        tmodel.addRow(b.getTableRow());
        JOptionPane.showMessageDialog(null, "Book Inserted");
    }

    public void updateClicked() {
        String sl = txtSl.getText();
        String title = txtTitle.getText();
        String author = txtAuthor.getText();
        String publicationYear = txtPublicationYear.getText();
        String price = txtPrice.getText();

        Book b = new Book(sl, title, author, publicationYear, price);

        BookManager bm = new BookManager();
        bm.updateBook(b);
        refreshTable();

        JOptionPane.showMessageDialog(null, "Updated");
    }

    public void deleteClicked() {
        String sl = txtSearch.getText();
        BookManager bm = new BookManager();
        bm.deleteBook(Integer.parseInt(sl));
        refreshTable();
        JOptionPane.showMessageDialog(null, "Deleted");
    }

    public void loadData() {
        BookManager bm = new BookManager();
        Book[] books = bm.getAllBooks();
        for (int i = 0; i < books.length; i++) {
            tmodel.addRow(books[i].getTableRow());
        }
    }

    public void searchClicked() {
        String sl = txtSearch.getText();
        BookManager bm = new BookManager();
        Book b = bm.searchBook(Integer.parseInt(sl));
        if (b == null) {
            JOptionPane.showMessageDialog(null, "Book not found");
        } else {
            txtSl.setText(b.getSl() + "");
            txtTitle.setText(b.getTitle());
            txtAuthor.setText(b.getAuthor());
            txtPublicationYear.setText(b.getPublicationYear() + "");
            txtPrice.setText(b.getPrice() + "");
        }
    }

    public void refreshTable() {
        tmodel.getDataVector().removeAllElements();
        BookManager bm = new BookManager();
        Book[] books = bm.getAllBooks();
        for (int i = 0; i < books.length; i++) {
            tmodel.addRow(books[i].getTableRow());
        }
    }
}
