package Entities;

public class Book {
    private int sl;
    private String title;
    private String author;
    private int publicationYear;
    private double price;

    public Book() {}

    public Book(int sl, String title, String author, int publicationYear, double price) {
        this.sl = sl;
        this.title = title;
        this.author = author;
        this.publicationYear = publicationYear;
        this.price = price;
    }

    public Book(String sl, String title, String author, String publicationYear, String price) {
        this.sl = Integer.parseInt(sl);
        this.title = title;
        this.author = author;
        this.publicationYear = Integer.parseInt(publicationYear);
        this.price = Double.parseDouble(price);
    }

    public void setTitle(String title) { this.title = title; }
    public void setAuthor(String author) { this.author = author; }
    public void setPublicationYear(int publicationYear) { this.publicationYear = publicationYear; }
    public void setPrice(double price) { this.price = price; }

    public int getSl() { return sl; }
    public String getTitle() { return title; }
    public String getAuthor() { return author; }
    public int getPublicationYear() { return publicationYear; }
    public double getPrice() { return price; }

    public void show() {
        System.out.println("Sl: " + sl);
        System.out.println("Title: " + title);
        System.out.println("Author: " + author);
        System.out.println("Publication Year: " + publicationYear);
        System.out.println("Price: " + price);
    }

    public String getFileWriteFormat() {
        return sl + ";" + title + ";" + author + ";" + publicationYear + ";" + price + "\n";
    }

    public Object[] getTableRow() {
        return new Object[] { sl, title, author, publicationYear, price };
    }
}
