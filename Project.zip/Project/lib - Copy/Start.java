import FileManagement.BookManager;
import Entities.Book;
import GUI.BookRegGUI;

public class Start {

    public static void main(String args[]) {
        BookRegGUI g = new BookRegGUI();
    }
}
