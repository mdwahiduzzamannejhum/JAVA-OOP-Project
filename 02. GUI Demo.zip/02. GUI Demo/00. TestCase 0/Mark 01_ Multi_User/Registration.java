import javax.swing.*;  
import java.awt.event.*;  
import static javax.swing.JOptionPane.showMessageDialog;
public class Registration implements ActionListener{  
    
	private JButton lgnBtn;
    private JButton signBtn;
    
    private JLabel lusn;
    private JLabel lpass;
    private JTextField uname;
    private JPasswordField upass;
	JFrame frame;
	
	//ASSOCIATION WITH USER CLASS
	User u1, u2, u3, u4;
	User users[];
	
    Registration(){  
	
		u1 = new User("Mazid", "1234");
		u2 = new User("ABCD", "9876");
		u3 = new User("John", "1234");
		u4 = new User("Peter", "1111");
		users = new User[4];
		users[0] = u1;
		users[1] = u2;
		users[2] = u3;
		users[3] = u4;
		
        //create frame
		frame = new JFrame ("System");
        //construct components
        lgnBtn = new JButton ("Register");
        signBtn = new JButton ("Clear");
        
        lusn = new JLabel ("Username");
        lpass = new JLabel ("Password");
        uname = new JTextField ();
        upass = new JPasswordField ();

        
		
		//set component bounds (only needed by Absolute Positioning)
        lgnBtn.setBounds (150, 185, 100, 30);
        signBtn.setBounds (305, 185, 100, 30);
        //exBtn.setBounds (205, 235, 140, 30);
        lusn.setBounds (150, 105, 100, 25);
        lpass.setBounds (150, 145, 100, 25);
        uname.setBounds (305, 105, 100, 25);
        upass.setBounds (305, 145, 100, 25);
		
		
		//addActionListener
		lgnBtn.addActionListener(this);
		signBtn.addActionListener(this);

        //add components
        frame.add (lgnBtn);
        frame.add (signBtn);
        //frame.add (exBtn);
        frame.add (lusn);
        frame.add (lpass);
        frame.add (uname);
        frame.add (upass);

        
		
		//frame properties
		//adjust size and set layout
        frame.setSize (624, 400);
		frame.setLocationRelativeTo(null);//to center screen gui
        frame.setLayout (null);
		frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
        frame.getContentPane();
        frame.setVisible (true); 
    }         
    public void actionPerformed(ActionEvent e) {  
         
        if(e.getSource()==lgnBtn)
		{  
			String name = uname.getText();
			String pass = upass.getText();
			
			User u = new User(name, pass);
			
			//addUser(u);
			
			
        }  
		else if(e.getSource() == signBtn)
		{
			
		}
    }  
} 