class Start {
 
    public static void main(String[] args) throws Exception
    {
        //new Registration();
		new Login();
    }
}