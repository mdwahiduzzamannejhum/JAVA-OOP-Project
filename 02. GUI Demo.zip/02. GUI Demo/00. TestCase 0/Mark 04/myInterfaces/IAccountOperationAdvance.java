package myInterfaces;
public interface IAccountOperationAdvance{
	public void showAllSavings();
}
