import java.lang.*;
import java.io.*;

public class CreateFile
{
	public static void main(String[] args)
	{
		try
		{
			File newFile = new File("C:\\Users\\mazid\\OneDrive\\Desktop\\JAVA\\File Demo\\new1.txt");
			if(newFile.createNewFile())
			{
				System.out.println("File creation successful!");
				System.out.println("File name: "+newFile.getName());
				System.out.println("File size in bytes: "+newFile.length());
			}
			else
			{
				System.out.println("File creation unsuccessful!");
			}
		}
		catch(IOException ioe)
		{
			System.out.println("Something went wrong!");
		}
	}
}