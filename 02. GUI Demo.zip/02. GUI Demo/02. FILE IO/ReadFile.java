import java.lang.*;
import java.io.*;
import java.util.*;

public class ReadFile
{
	public static void main(String[] args)
	{
		try
		{
			File newFile = new File("C:\\Users\\mazid\\OneDrive\\Desktop\\JAVA\\File Demo\\new1.txt");
			Scanner sc = new Scanner(newFile);
			
			while(sc.hasNext())
			{
				String s1 = sc.nextLine();
				String s2 = sc.nextLine();
				
				System.out.println(s1);
				System.out.println(s2);
				System.out.println("Reading successful!");
				System.out.println("File name: "+newFile.getName());
				System.out.println("File size in bytes: "+newFile.length());
				
			}
			
		}
		catch(IOException ioe)
		{
			System.out.println("Something went wrong!");
		}
	}
}