import java.lang.*;
import java.io.*;
import java.util.*;

public class WriteFile
{
	public static void main(String[] args)
	{
		try
		{
			Scanner sc = new Scanner(System.in);
			FileWriter newFile = new FileWriter("C:\\Users\\mazid\\OneDrive\\Desktop\\JAVA\\File Demo\\new1.txt");
			
			System.out.println("Enter a string: ");
			String s = sc.nextLine();
			
			
			
			//newFile.write("Hello there!\n How are you?");
			
			newFile.write(s);
			
			System.out.println("Writing successful!");
			newFile.close();
		}
		catch(IOException ioe)
		{
			System.out.println("Something went wrong!");
		}
	}
}