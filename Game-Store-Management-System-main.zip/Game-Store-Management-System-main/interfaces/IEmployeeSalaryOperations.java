package interfaces;
import java.util.*;
import java.lang.*;
import classes.*;

public interface IEmployeeSalaryOperations
{
  void increaseSalary(double amount);
  void decreaseSalary(double amount);
}
