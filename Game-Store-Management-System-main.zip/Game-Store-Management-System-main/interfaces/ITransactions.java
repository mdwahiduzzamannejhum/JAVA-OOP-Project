package interfaces;
import java.util.*;
import java.lang.*;
import classes.*;

public interface ITransactions
{
  void Withdraw(double amount);
  void Deposit(double amount);
}
